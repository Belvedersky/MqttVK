self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "193036b15d96c0b9449abb6ab9866b8f",
    "url": "/index.html"
  },
  {
    "revision": "4b013f7470e4a336c571",
    "url": "/static/css/2.abebce0a.chunk.css"
  },
  {
    "revision": "4b013f7470e4a336c571",
    "url": "/static/js/2.be67bc61.chunk.js"
  },
  {
    "revision": "b18d53aeff374d92529280bc8e32ca95",
    "url": "/static/js/2.be67bc61.chunk.js.LICENSE.txt"
  },
  {
    "revision": "c17ab8e4940b081e5880",
    "url": "/static/js/main.342d38a8.chunk.js"
  },
  {
    "revision": "5b56119efba7f7d29413",
    "url": "/static/js/runtime-main.d08df855.js"
  }
]);